#!/usr/bin/env python

from distutils.core import setup

setup(name='DynamicForm',
      version='0.2',
      description='DynamicForm is an AJAX abstraction library for python - that enables different sections of a page independently.',
      author='Timothy Crosley',
      author_email='timothy.crosley@gmail.com',
      url='http://www.dynamicform.org/',
      download_url='https://github.com/timothycrosley/DynamicForm/blob/master/dist/DynamicForm-0.1.tar.gz?raw=true',
      license = "GNU GPLv2",
      packages=['DynamicForm',],)
